import com.xn.dao.StrawberryhouseDao;
import com.xn.entity.Strawberryhouse;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class test_1 {
    InputStream resourceAsStream = null;
    SqlSessionFactory sessionFactory = null;
    SqlSession sqlSession = null;
    StrawberryhouseDao ud = null;
    @Before
    public void before() throws IOException {
        resourceAsStream = Resources.getResourceAsStream("mybatis-config.xml");
        sessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
        sqlSession = sessionFactory.openSession();
        ud = sqlSession.getMapper(StrawberryhouseDao.class);
    }
    @Test
    public void queryAll() throws IOException {
        List<Strawberryhouse> all = ud.findAll();
        for (Strawberryhouse strawberryhouse : all) {
            System.out.println(strawberryhouse);
        }
        //Strawberryhouse strawberryhouse = new Strawberryhouse(all.get(0));
        System.out.println(all.get(4).getAirHumidity());
    }
}
