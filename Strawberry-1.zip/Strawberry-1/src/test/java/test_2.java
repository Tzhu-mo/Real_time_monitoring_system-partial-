import com.xn.entity.Strawberryhouse;
import org.junit.After;
import org.junit.Test;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class test_2 {
    private static final String driverName = "org.apache.hive.jdbc.HiveDriver";
    private static final String url = "jdbc:hive2://192.168.52.134:10000";
    private static final String dbName = "strawberry";
    private static Connection con = null;
    private static Statement state = null;
    private static ResultSet res = null;
    @After
    public void destory() throws SQLException {
        if (res != null) state.close();
        if (state != null) state.close();
    }
    public static void init() {
        try {
            Class.forName(driverName);
            con = DriverManager.getConnection(url + "/" + dbName);
            state = con.createStatement();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
    public static List<Strawberryhouse> shift(ResultSet res) throws SQLException {
        List<Strawberryhouse> houses = null;
        houses = new ArrayList<>();
        while (res.next()) {
            // 创建新的StrawberryHouse对象
            Strawberryhouse house = new Strawberryhouse(all.get(0));

            // 设置对象属性
            house.setEShelfId(res.getString("LargeShelfId"));
            house.setTime(res.getString("Time"));
            house.setAirHumidity(res.getInt("AirHumidity"));
            house.setAirTemperature(res.getInt("AirTemperature"));
            house.setSoilHumidity(res.getInt("SoilHumidity"));
            house.setSoilTemperature(res.getInt("SoilTemperature"));
            house.setCO2(res.getInt("CO2"));
            house.setLIghtIbtensity(res.getInt("LIghtIbtensity"));
            house.setSensorStatus(res.getString("SensorStatus"));
            house.setHeaterStatus(res.getString("HeaterStatus"));
            house.setHumidifierStatus(res.getString("HumidifierStatus"));
            // 将对象添加到列表中
            houses.add(house);
        }
        return houses;
    }

    @Test
    public void showtDb() throws SQLException, ClassNotFoundException {
        Class.forName(driverName);
        con = DriverManager.getConnection(url);
        state = con.createStatement();
        res = state.executeQuery("show databases");
    }

    @Test
    public void selectTab() throws SQLException {
        init();
        res = state.executeQuery("select * from strawberryhouse limit 5");
        List<Strawberryhouse> all = shift(res);
        for (Strawberryhouse house : all) {
            System.out.println("1");
            System.out.println(house);
        }
    }
}

