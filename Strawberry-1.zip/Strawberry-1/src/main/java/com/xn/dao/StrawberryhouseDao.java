package com.xn.dao;

import com.xn.entity.Strawberryhouse;

import java.util.List;

public interface StrawberryhouseDao {
    List<Strawberryhouse> findAll();
}
