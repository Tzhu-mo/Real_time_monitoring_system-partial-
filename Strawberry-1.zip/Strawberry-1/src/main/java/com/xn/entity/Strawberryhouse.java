package com.xn.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Strawberryhouse {
    private String eShelfId;
    private String time;
    private int AirTemperature;
    private int AirHumidity;
    private int SoilTemperature;
    private int SoilHumidity;
    private int CO2;
    private int LIghtIbtensity;
    private String HeaterStatus;
    private String HumidifierStatus;
    private String SensorStatus;

}
