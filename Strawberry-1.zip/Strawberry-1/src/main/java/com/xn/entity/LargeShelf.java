package com.xn.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class LargeShelf {
    private String LargeShelfId;
    private String Strawberry;
    private int area;

}
