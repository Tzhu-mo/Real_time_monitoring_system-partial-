import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class jiqixuexi {

    public static void main(String[] args) {
        String[] years = {"2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021"};

        for (String year : years) {
            String filename = "data_" + year + ".csv";

            try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
                // Write headers
                writer.println("日期,日平均气温(℃),日最高温度(℃),日最低温度(℃),空气湿度(%),日照时数(h),土壤湿度(%),土壤温度(℃),土壤pH值,土壤有机质含量(%),土壤氮含量(mg/kg),土壤磷含量(mg/kg),土壤钾含量(mg/kg),平均株高(cm),平均果实数量,果实平均大小(g),虫害程度");

                // Generate data for each day in the year
                LocalDate startDate = LocalDate.of(Integer.parseInt(year), 3, 1);
                LocalDate endDate = LocalDate.of(Integer.parseInt(year), 5, 1);

                Random random = new Random();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                for (LocalDate date = startDate; date.isBefore(endDate); date = date.plusDays(1)) {
                    StringBuilder sb = new StringBuilder();

                    // Date
                    sb.append(date.format(formatter)).append(",");

                    // Random data
                    sb.append(15 + random.nextFloat() * 10).append(",");    // 日平均气温(℃)
                    sb.append(20 + random.nextFloat() * 10).append(",");    // 日最高温度(℃)
                    sb.append(5 + random.nextFloat() * 5).append(",");      // 日最低温度(℃)
                    sb.append(60 + random.nextFloat() * 20).append(",");   // 空气湿度(%)
                    sb.append(6 + random.nextInt(3)).append(",");          // 日照时数(h)
                    sb.append(60 + random.nextFloat() * 20).append(",");   // 土壤湿度(%)
                    sb.append(15 + random.nextFloat() * 10).append(",");   // 土壤温度(℃)
                    sb.append(5.5 + random.nextFloat()).append(",");       // 土壤pH值
                    sb.append(2 + random.nextFloat() * 3).append(",");     // 土壤有机质含量(%)
                    sb.append(100 + random.nextFloat() * 100).append(","); // 土壤氮含量(mg/kg)
                    sb.append(10 + random.nextFloat() * 10).append(",");   // 土壤磷含量(mg/kg)
                    sb.append(100 + random.nextFloat() * 100).append(","); // 土壤钾含量(mg/kg)
                    sb.append(15 + random.nextFloat() * 15).append(",");   // 平均株高(cm)
                    sb.append(10 + random.nextFloat() * 10).append(",");   // 平均果实数量
                    sb.append(5 + random.nextFloat() * 25).append(",");    // 果实平均大小(g)
                    sb.append(1 + random.nextInt(3));                     // 虫害程度

                    writer.println(sb.toString());
                }

                System.out.println("CSV文件已生成：" + filename);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
