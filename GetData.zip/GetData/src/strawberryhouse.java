import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class strawberryhouse {

    public static void main(String[] args) {
        String filename = "generated_data.csv"; // 输出到csv文件，后续可手动转换为excel
        generateAndExportData(filename);
        System.out.println("数据生成并输出到 " + filename);
    }

    public static void generateAndExportData(String filename) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            // 输出CSV文件的表头
            writer.println("日期时间,温度(℃),空气湿度(%),土壤温度(℃),土壤湿度(%),二氧化碳浓度(ppm),光照强度(lux)");

            // 设置起始日期时间
            Calendar calendar = Calendar.getInstance();
            calendar.set(2024, Calendar.MARCH, 1, 6, 0); // 设置为2024年3月1日上午6点

            // 设置结束日期时间
            Calendar endCalendar = Calendar.getInstance();
            endCalendar.set(2024, Calendar.APRIL, 30, 6, 0); // 设置为2024年4月30日上午6点

            // 遍历每小时数据
            while (calendar.before(endCalendar)) {
                // 生成随机数据
                String dateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(calendar.getTime());
                int temperature = generateTemperature(calendar);
                int airHumidity = generateAirHumidity();
                int soilTemperature = generateSoilTemperature();
                int soilHumidity = generateSoilHumidity();
                int co2Concentration = generateCO2Concentration();
                int lightIntensity = generateLightIntensity(calendar);

                // 写入数据到CSV文件
                writer.printf("%s,%d,%d,%d,%d,%d,%d\n", dateTime, temperature, airHumidity, soilTemperature, soilHumidity, co2Concentration, lightIntensity);

                // 增加一个小时
                calendar.add(Calendar.HOUR_OF_DAY, 1);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 生成温度数据
    private static int generateTemperature(Calendar calendar) {
        int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);
        if (hourOfDay >= 6 && hourOfDay <= 12) {
            // 上午6点到中午12点，温度递增
            return 10 + (hourOfDay - 6);
        } else if (hourOfDay >= 0 && hourOfDay <= 5) {
            return 10;
        } else {
            // 其余时间温度递减
            return 22 - (hourOfDay - 12);
        }
    }

    // 生成空气湿度数据
    private static int generateAirHumidity() {
        Random random = new Random();
        return random.nextInt(21) + 50; // 50至70之间的随机数
    }

    // 生成土壤温度数据
    private static int generateSoilTemperature() {
        Random random = new Random();
        return random.nextInt(6) + 15; // 15至20之间的随机数
    }

    // 生成土壤湿度数据
    private static int generateSoilHumidity() {
        Random random = new Random();
        return random.nextInt(21) + 60; // 60至80之间的随机数
    }

    // 生成二氧化碳浓度数据
    private static int generateCO2Concentration() {
        Random random = new Random();
        return random.nextInt(201) + 600; // 600至800之间的随机数
    }

    // 生成光照强度数据
    private static int generateLightIntensity(Calendar calendar) {
        int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);
        if (hourOfDay >= 8 && hourOfDay <= 16) {
            Random random = new Random();
            return random.nextInt(10001) + 20000; // 20000至30000之间的随机数
        } else {
            return 0; // 其余时间为0
        }
    }
}

