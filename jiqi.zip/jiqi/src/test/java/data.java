import weka.core.Instances;
import weka.core.converters.CSVLoader;
import weka.core.converters.ArffSaver;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;

import java.io.File;
import java.io.IOException;

public class data {
    public static void main(String[] args) {
        try {
            // 加载CSV文件
            CSVLoader loader = new CSVLoader();
            loader.setSource(new File("D:\\Yuce\\src\\main\\java\\Export_train.csv"));
            Instances data = loader.getDataSet();

            /*Remove removeFilter = new Remove();
            removeFilter.setAttributeIndices("1");// 注意：WEKA的列索引是从1开始的
            removeFilter.setInputFormat(data);
            data = Filter.useFilter(data, removeFilter);

            Remove removeFilter_1 = new Remove();
            removeFilter_1.setAttributeIndices("17");// 注意：WEKA的列索引是从1开始的
            removeFilter_1.setInputFormat(data);
            data = Filter.useFilter(data, removeFilter_1);*/

            // 确保类索引已经设置
            if (data.classIndex() == -1)
                data.setClassIndex(data.numAttributes() - 1);

            // 保存为ARFF格式
            ArffSaver saver = new ArffSaver();
            saver.setInstances(data);
            saver.setFile(new File("D:\\Yuce\\src\\main\\java\\Export_train.arff"));
            saver.writeBatch();

            System.out.println("Conversion successful.");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}